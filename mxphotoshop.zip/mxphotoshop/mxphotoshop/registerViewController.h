//
//  registerViewController.h
//  mxphotoshop
//
//  Created by star on 16/6/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "registerView.h"

@interface registerViewController : UIViewController

@property(nonatomic,strong) registerView* regView;

@end
