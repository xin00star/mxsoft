//
//  AppDelegate.h
//  mxphotoshop
//
//  Created by star on 16/6/16.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
@class mxViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) mxViewController *viewController;
@property (strong, nonatomic) UINavigationController *navgationController;

@end