//
//  firstViewController.h
//  mxphotoshop
//
//  Created by star on 16/6/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface firstViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (nonatomic,assign) IBOutlet UIScrollView* sv;
@property (nonatomic,assign) IBOutlet UIImageView* iv;
@property (nonatomic,assign) IBOutlet UISlider* usb;
@property (nonatomic,assign) IBOutlet UISlider* uscon;
@property (nonatomic,assign) IBOutlet UISlider* usc;
@property (nonatomic,assign) IBOutlet UILabel* lb;
@property (nonatomic,assign) IBOutlet UILabel* lcon;
@property (nonatomic,assign) IBOutlet UILabel* lc;
@property (nonatomic,strong) UIImage* source;
@property (nonatomic,strong) UIImage* edited;
@property (nonatomic,assign) float b;
@property (nonatomic,assign) float c;
@property (nonatomic,assign) float con;

-(IBAction)put1;
-(IBAction)put2;
-(IBAction)put3;
-(IBAction)put4;
-(IBAction)put5;
-(IBAction)put6;
-(IBAction)put7;
-(IBAction)put8;
-(IBAction)put9;
-(IBAction)put10;
-(IBAction)sliderValueWithBright;
-(IBAction)sliderValueWithContract;
-(IBAction)sliderValueWithColor;

-(void)waitAdd;
-(void)waitTake;
-(IBAction)optimize;
-(IBAction)addphoto;
-(IBAction)takephoto;
-(IBAction)rollback;
-(IBAction)save;
-(void)showSave:(UIImage*)image didSavingWithError:(NSError*)error contextInfo:(void*)info;

-(IBAction)back;

@end
