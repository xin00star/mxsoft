//
//  secondViewController.h
//  mxphotoshop
//
//  Created by star on 16/6/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "drawView.h"

@interface secondViewController : UIViewController

@property (nonatomic,strong) UIButton* color;
@property (nonatomic,strong) UIButton* line;
@property (nonatomic,strong) UIButton* red;
@property (nonatomic,strong) UIButton* yellow;
@property (nonatomic,strong) UIButton* green;
@property (nonatomic,strong) UIButton* blue;
@property (nonatomic,strong) UIButton* purple;
@property (nonatomic,strong) UIButton* gray;
@property (nonatomic,strong) UIButton* black;
@property (nonatomic,strong) UIButton* s;
@property (nonatomic,strong) UIButton* m;
@property (nonatomic,strong) UIButton* l;

@property (nonatomic,strong)  UIImageView *iv;
@property (nonatomic,strong)  drawView *drawView;
@property (nonatomic,assign)  BOOL buttonHidden;
@property (nonatomic,assign)  BOOL widthHidden;

@end
