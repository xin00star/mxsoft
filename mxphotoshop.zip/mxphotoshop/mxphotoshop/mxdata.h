//
//  mxdata.h
//  mxphotoshop
//
//  Created by star on 16/6/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface mxdata : NSObject

@property(nonatomic,strong) NSData* data;
@property(nonatomic,assign) NSInteger i;

@end
