//
//  textFieldView.m
//  mxphotoshop
//
//  Created by star on 16/6/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "textFieldView.h"

@implementation textFieldView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    CGContextRef ref=UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(ref,[UIColor grayColor].CGColor);
    CGContextFillRect(ref,CGRectMake(0,CGRectGetHeight(self.frame)-1,CGRectGetWidth(self.frame), 1));
}

@end
