//
//  mxSideViewController.h
//  mxphotoshop
//
//  Created by star on 16/6/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mxSideBar.h"

typedef void (^didSelectRowAtIndexPath)(NSIndexPath *indexPath);

@interface mxSideViewController : mxSideBar

@property(nonatomic,copy) didSelectRowAtIndexPath didSelectRowAtIndexPath;
@property(nonatomic,strong) UITableView* menuTableView;
@property(nonatomic,strong) UILabel* infoLabel;

-(void)didSelectRowAtIndexPath:(didSelectRowAtIndexPath)didSelectRowAtIndexPath;

@end
