//
//  thirdViewController.h
//  mxphotoshop
//
//  Created by star on 16/6/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "webViewController.h"
#import "notifyViewController.h"
#import "ioViewController.h"
#import "openGLViewController.h"
#import "CAViewController.h"

@interface thirdViewController : UIViewController

@property(nonatomic,strong) UITableView* tv;
@property(nonatomic,strong) NSArray* list;

@property(nonatomic,strong) webViewController* wvc;
@property(nonatomic,strong) notifyViewController* nvc;
@property(nonatomic,strong) ioViewController* ivc;
@property(nonatomic,strong) openGLViewController* ovc;
@property(nonatomic,strong) CAViewController* cvc;

@end
