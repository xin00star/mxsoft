//
//  ViewController.h
//  mxphotoshop
//
//  Created by star on 16/6/16.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mxSideViewController.h"
#import "firstViewController.h"
#import "secondViewController.h"
#import "thirdViewController.h"
#import "fourthViewController.h"
#import "loadViewController.h"
#import "registerViewController.h"

@interface mxViewController : UIViewController

@property(nonatomic,strong) mxSideViewController* sidebarVC;
@property(nonatomic,strong) firstViewController* fvc;
@property(nonatomic,strong) secondViewController* svc;
@property(nonatomic,strong) thirdViewController* tvc;
@property(nonatomic,strong) fourthViewController* frvc;
@property(nonatomic,strong) UIImage* bg;

@property(nonatomic,weak) IBOutlet UILabel* l;
@property(nonatomic,weak) IBOutlet UIButton* b;
@property(nonatomic,weak) IBOutlet UIButton* r;

-(IBAction)login;
-(IBAction)reg;
-(IBAction)show;

@end

