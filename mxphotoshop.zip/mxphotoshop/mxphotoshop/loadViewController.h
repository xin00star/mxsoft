//
//  loadViewController.h
//  mxphotoshop
//
//  Created by star on 16/6/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "loginView.h"

typedef void (^nameblock)(NSString* username);

@interface loadViewController : UIViewController

@property(nonatomic,copy) nameblock nblock;
@property(nonatomic,strong) loginView* loginView;

-(void)didLogin:(nameblock)block;
-(IBAction)del;

@end
