//
//  drawView.h
//  mxphotoshop
//
//  Created by star on 16/6/21.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface drawView : UIView

-(void)addPA:(CGPoint)nPoint;
-(void)addLA;
-(void)revocation;
-(void)refrom;
-(void)clear;
-(void)setLineColor:(int)color;
-(void)setlineWidth:(int)width;

@end
