//
//  textFieldView.h
//  mxphotoshop
//
//  Created by star on 16/6/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface textFieldView : UITextField

@end
