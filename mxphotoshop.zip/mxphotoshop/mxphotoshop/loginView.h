//
//  loginView.h
//  mxphotoshop
//
//  Created by star on 16/6/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "textFieldView.h"

@interface loginView : UIView

@property(nonatomic,strong) UILabel* name;
@property(nonatomic,strong) UILabel* pass;
@property(nonatomic,strong) textFieldView* namet;
@property(nonatomic,strong) textFieldView* passt;

@end
