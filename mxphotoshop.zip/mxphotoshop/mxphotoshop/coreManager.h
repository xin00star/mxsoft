//
//  userDAO.h
//  mxphotoshop
//
//  Created by star on 16/6/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface coreManager : NSObject

//被管理对象上下文(Managed Object Context,MOC)类,在上下文中可以crud对象,然后持久化对象存储。
@property (readonly, strong, nonatomic) NSManagedObjectContext* managedObjectContext;
//被管理对象模型(Managed Object Model,MOM)类,是系统中的“实体”,与数据库中的表等对象对应。
@property (readonly, strong, nonatomic) NSManagedObjectModel* managedObjectModel;
//被管理对象和数据库的连接
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator* persistentStoreCoordinator;

-(void)saveContext;
-(NSURL*)applicationDocumentsDirectory;
+(coreManager*)sharedManager;

@end
