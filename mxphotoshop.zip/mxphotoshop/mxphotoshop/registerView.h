//
//  register.h
//  mxphotoshop
//
//  Created by star on 16/6/20.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "textFieldView.h"

@interface registerView : UIView

@property(nonatomic,strong) UILabel* name;
@property(nonatomic,strong) UILabel* pass;
@property(nonatomic,strong) UILabel* sure;
@property(nonatomic,strong) textFieldView* namet;
@property(nonatomic,strong) textFieldView* passt;
@property(nonatomic,strong) textFieldView* suret;

@end
