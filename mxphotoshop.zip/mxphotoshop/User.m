//
//  User.m
//  mxphotoshop
//
//  Created by star on 16/6/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "User.h"

@implementation User

// Insert code here to add functionality to your managed object subclass

@end
